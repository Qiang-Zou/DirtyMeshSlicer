#include "OpenMesh.h"


//std::shared_ptr<Geometry> QOpenMesh::GetEntities2Slice(bool isIncremental, double height)
//{

//}

GeometryTypes QOpenMesh::GetGeometryType()
{
     return SurfaceMeshOpenMesh;
}
